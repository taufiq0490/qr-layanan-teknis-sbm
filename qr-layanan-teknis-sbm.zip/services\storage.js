const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, '..', 'config.json');
const TICKETS_PATH = path.join(__dirname, '..', 'tickets.json');

function readConfig() {
  try {
    if (!fs.existsSync(CONFIG_PATH)) {
      const defaultConfig = {
        appTitle: "Layanan Bantuan Teknis SBM ITB Jakarta",
        rooms: [
          "Henk Uno",
          "Kirana Megatara 1",
          "Kirana Megatara 2",
          "Noni Purnomo",
          "Medco",
          "12A Room"
        ],
        messageTemplate: "Mohon bantuan teknis di ruang {room} SEGERA!",
        waGateway: {
          provider: "fonnte",
          fonnteToken: "",
          staffNumbers: [],
          countryCode: "62",
          webhookUrl: ""
        },
        adminPassword: "admin"
      };
      fs.writeFileSync(CONFIG_PATH, JSON.stringify(defaultConfig, null, 2), 'utf-8');
      return defaultConfig;
    }
    const data = fs.readFileSync(CONFIG_PATH, 'utf-8');
    return JSON.parse(data);
  } catch (err) {
    console.error("Error reading config:", err);
    return {};
  }
}

function saveConfig(config) {
  try {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error("Error saving config:", err);
    return false;
  }
}

function readTickets() {
  try {
    if (!fs.existsSync(TICKETS_PATH)) {
      fs.writeFileSync(TICKETS_PATH, JSON.stringify([], null, 2), 'utf-8');
      return [];
    }
    const data = fs.readFileSync(TICKETS_PATH, 'utf-8');
    return JSON.parse(data);
  } catch (err) {
    console.error("Error reading tickets:", err);
    return [];
  }
}

function saveTickets(tickets) {
  try {
    fs.writeFileSync(TICKETS_PATH, JSON.stringify(tickets, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error("Error saving tickets:", err);
    return false;
  }
}

function createTicket(room, category = "Umum", notes = "") {
  const tickets = readTickets();
  const newTicket = {
    id: "TICK-" + Date.now().toString(36).toUpperCase() + "-" + Math.floor(Math.random() * 1000),
    room,
    category: category || "Umum",
    notes: notes || "",
    status: "Menunggu", // 'Menunggu', 'Diproses', 'Selesai'
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    waStatus: {
      sent: false,
      timestamp: null,
      details: null
    }
  };
  tickets.unshift(newTicket);
  saveTickets(tickets);
  return newTicket;
}

function updateTicketStatus(id, status, handledBy = "") {
  const tickets = readTickets();
  const ticket = tickets.find(t => t.id === id);
  if (ticket) {
    ticket.status = status;
    ticket.updatedAt = new Date().toISOString();
    if (handledBy) ticket.handledBy = handledBy;
    saveTickets(tickets);
    return ticket;
  }
  return null;
}

function updateTicketWaStatus(id, waStatus) {
  const tickets = readTickets();
  const ticket = tickets.find(t => t.id === id);
  if (ticket) {
    ticket.waStatus = waStatus;
    ticket.updatedAt = new Date().toISOString();
    saveTickets(tickets);
    return ticket;
  }
  return null;
}

module.exports = {
  readConfig,
  saveConfig,
  readTickets,
  saveTickets,
  createTicket,
  updateTicketStatus,
  updateTicketWaStatus
};
